export const baseURL = 'https://fakestoreapi.com/'

export const endPoints ={
    product:'/products',
    details: (id) => `/products/${id}`,
}